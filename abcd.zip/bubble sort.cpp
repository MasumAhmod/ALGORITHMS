#include <bits/stdc++.h>
using namespace std;

#define MOD 10000007
#define endl '\n'

int main()
{
    int t;
    cin >> t;

    for(int i=1; i <= t; i++){
        int n;
        cin >> n;
        int a[n];
        for(int j=0; j < n; j++) cin >> a[j];
        int cnt = 0;
        for(int b = 0; b < n - 1; b++){
            for(int c = 0; c < n - b - 1; c++){
                if(a[c] > a[c + 1]){
                    swap(a[c] , a[c + 1]);
                    cnt++;
                }
            }
        }
        cout << "Case " << i << ": " << cnt % MOD << endl;
    }
}
